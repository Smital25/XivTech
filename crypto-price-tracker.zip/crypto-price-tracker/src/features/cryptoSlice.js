import { createSlice } from '@reduxjs/toolkit';

const sampleData = [
  {
    id: 'btc',
    name: 'Bitcoin',
    symbol: 'BTC',
    price: 65375.51,
    change1h: -3.12,
    change24h: -12.35,
    change7d: 4.30,
    marketCap: 1200000000000,
    volume24h: 29998414978275,
    circulatingSupply: 19000000,
    maxSupply: 21000000,
    logo: 'crypto-price-tracker/src/assets/btc.png',
    chart7d: 'crypto-price-tracker/src/assets/chart.png'
  },
  {
    id: 'eth',
    name: 'Ethereum',
    symbol: 'ETH',
    price: 2934.25,
    change1h: -5.70,
    change24h: -11.68,
    change7d: 5.90,
    marketCap: 567890123,
    volume24h: 108462771978,
    circulatingSupply: 120000000,
    maxSupply: null,
    logo: 'crypto-price-tracker/src/assets/eth.png',
    chart7d: 'crypto-price-tracker/src/assets/btc.png'
  },
  {
    id: 'usdt',
    name: 'Tether',
    symbol: 'USDT',
    price: 1.00,
    change1h: -0.02,
    change24h: 0.00,
    change7d: 0.01,
    marketCap: 80000000000,
    volume24h: 59997976764738,
    circulatingSupply: 80000000000,
    maxSupply: null,
    logo: 'crypto-price-tracker/src/assets/usdt.png',
    chart7d: 'crypto-price-tracker/src/assets/btc.png'
  },
  {
    id: 'bnb',
    name: 'BNB',
    symbol: 'BNB',
    price: 281.83,
    change1h: -2.04,
    change24h: 2.62,
    change7d: 1.70,
    marketCap: 70000000000,
    volume24h: 1402713969089,
    circulatingSupply: 160000000,
    maxSupply: 200000000,
    logo: '/bnb.svg',
    chart7d: '/chart.svg'
  },
  {
    id: 'sol',
    name: 'Solana',
    symbol: 'SOL',
    price: 529.63,
    change1h: 0.41,
    change24h: 4.49,
    change7d: 4.80,
    marketCap: 62000000000,
    volume24h: 2198686702831,
    circulatingSupply: 430000000,
    maxSupply: null,
    logo: '/sol.svg',
    chart7d: '/chart.svg'
  }
];

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState: sampleData,
  reducers: {
    updatePrices(state) {
      state.forEach(asset => {
        asset.price += (Math.random() - 0.5) * 500;
        asset.change1h += (Math.random() - 0.5) * 2;
        asset.change24h += (Math.random() - 0.5) * 5;
        asset.volume24h += (Math.random() - 0.5) * 1000000;
      });
    },
  },
});

export const { updatePrices } = cryptoSlice.actions;
export default cryptoSlice.reducer;
