// src/components/CryptoTable.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import './CryptoTable.css';

const formatNumber = (num) =>
  num?.toLocaleString(undefined, { maximumFractionDigits: 2 });

const CryptoTable = () => {
  const assets = useSelector((state) => state.crypto);

  return (
    <div className="crypto-table-container">
      <table className="crypto-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Logo</th>
            <th>Name</th>
            <th>Symbol</th>
            <th>Price</th>
            <th>1h %</th>
            <th>24h %</th>
            <th>7d %</th>
            <th>Market Cap</th>
            <th>24h Volume</th>
            <th>Circulating</th>
            <th>Max Supply</th>
            <th>7D Chart</th>
          </tr>
        </thead>
        <tbody>
          {assets.map((asset, index) => (
            <tr key={asset.id}>
              <td>{index + 1}</td>
              <td><img src={asset.logo} alt={asset.name} className="logo" /></td>
              <td>{asset.name}</td>
              <td>{asset.symbol}</td>
              <td>${formatNumber(asset.price)}</td>
              <td className={asset.change1h > 0 ? 'positive' : 'negative'}>{formatNumber(asset.change1h)}%</td>
              <td className={asset.change24h > 0 ? 'positive' : 'negative'}>{formatNumber(asset.change24h)}%</td>
              <td className={asset.change7d > 0 ? 'positive' : 'negative'}>{formatNumber(asset.change7d)}%</td>
              <td>${formatNumber(asset.marketCap)}</td>
              <td>${formatNumber(asset.volume24h)}</td>
              <td>{formatNumber(asset.circulatingSupply)}</td>
              <td>{asset.maxSupply ? formatNumber(asset.maxSupply) : '∞'}</td>
              <td><img src={asset.chart7d} alt="Chart" className="chart" /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CryptoTable;
